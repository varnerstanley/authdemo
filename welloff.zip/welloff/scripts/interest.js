function calculate() {
                p = document.getElementById("p").value;
                n = document.getElementById("n").value;
                r = document.getElementById("r").value;
                result = document.getElementById("result");

                result.innerHTML = "The interest is $" + (p*n*r/100) + ". " + '<br>' + "BAM! " + '<br>' + "How does that feel?" + '<br>' + "What's the lesson?" + '<br>' + "DON'T BORROW MONEY!";
            }
